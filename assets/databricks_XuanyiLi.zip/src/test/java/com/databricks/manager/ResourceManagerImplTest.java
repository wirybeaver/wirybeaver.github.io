package com.databricks.manager;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static  org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * use mockito
 * This suite should test basic functionality of ResourceManagerImpl implementation.
 */
public class ResourceManagerImplTest {
    private CloudProvider provider;

    @Before
    public void init(){
        provider = mock(CloudProvider.class);
    }


    @Test
    public void testPlaceContainerCaseA(){
        // basic case: instanceSize is divisible by containerSize
        // sequential request
        double instanceSize = 2;
        double containerSize = 1;
        when(provider.requestInstance()).thenAnswer( prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);
        for(int i=0; i<100; i++){
            manager.placeContainers(1);
        }
        verify(provider, times(50)).requestInstance();
    }

    @Test
    public void testPlaceContainerCaseB(){
        // basic case: instanceSize is not divsible by containerSize
        // sequential request
        double instanceSize = 3;
        double containerSize = 2;
        when(provider.requestInstance()).thenAnswer(prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);
        for(int i=0; i<100; i++){
            manager.placeContainers(1);
        }
        verify(provider, times(100)).requestInstance();
    }

    @Test
    public void testPlaceContainerCaseC(){
        // mock 100 concurrent request for containers, test thread safety
        double instanceSize = 2;
        double containerSize = 1;
        when(provider.requestInstance()).thenAnswer(prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);
        CountDownLatch countDownLatch = new CountDownLatch(100);

        //start 100 user thread
        for(int i=0; i<100; i++){
            // each user require 1 container
            new Thread(new ReqUser(manager,countDownLatch, 1)).start();
        }

        try {
            // wait until all "request" thread finishes
            countDownLatch.await();
            verify(provider, times(50)).requestInstance();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetInstanceId(){
        double instanceSize = 2;
        double containerSize = 1;
        when(provider.requestInstance()).thenAnswer(prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);

        List<ContainerId> containerId = manager.placeContainers(2);
        Assert.assertEquals(manager.getInstanceId(containerId.get(0)),
                manager.getInstanceId(containerId.get(1)));

    }

    @Test
    public void testUnplaceContainer(){
        // basic sequential case, no concurrent
        // request 2 containers, deallocate them, request 2 new containers again
        // the requestInstance() of provider will not be called during the latter request
        // since after de-allocation, space is free enough to place new containers.
        double instanceSize = 2;
        double containerSize = 1;
        when(provider.requestInstance()).thenAnswer( prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);
        List<ContainerId> cand = new ArrayList<>();
        cand.addAll(manager.placeContainers(2));
        // unplace containers
        cand.stream().forEach( manager::unplaceContainer);
        manager.placeContainers(2);
        verify(provider, times(1)).requestInstance();
    }

    @Test
    public void testUnplaceContainerConcurrent(){
        // test for thread safety
        double instanceSize = 2;
        double containerSize = 1;
        when(provider.requestInstance()).thenAnswer( prov -> new InstanceImpl(instanceSize));
        ResourceManager manager = new ResourceManagerImpl(provider, instanceSize, containerSize);
        CountDownLatch countDownLatch = new CountDownLatch(200);
        List<ContainerId> cand = new ArrayList<>();

        // first for loop to request 200 containers
        for(int i=0; i<100; i++){
            cand.addAll(manager.placeContainers(2));
        }
        Assert.assertEquals(cand.size(), 200);

        // second for loop to unplace 200 containers
        for(ContainerId id : cand){
            new Thread(new UnplaceUser(manager,countDownLatch, id)).start();
        }
        try {
            // wait until all "unplace" thread finish
            countDownLatch.await();

            // require containers with same amount
            for(int i=0; i<100; i++){
                manager.placeContainers(2);
            }

            // since all instance have full capacity, the function "requestInstance" would not be called
            // the first for loop exactly contributes to the called times of function "requestInstance"
            verify(provider, times(100)).requestInstance();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}

// represent a single user thread
abstract class BaseUser implements Runnable{
    protected final ResourceManager manager;
    protected final CountDownLatch countDownLatch;

    public BaseUser(ResourceManager manager, CountDownLatch countDownLatch) {
        this.manager = manager;
        this.countDownLatch = countDownLatch;
    }

}

// request #numContainer containers
class ReqUser extends  BaseUser{
    private int numContainer;

    public ReqUser(ResourceManager manager, CountDownLatch countDownLatch, int numContainer) {
        super(manager, countDownLatch);
        this.numContainer = numContainer;
    }

    @Override
    public void run() {
        try{
            manager.placeContainers(numContainer);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            countDownLatch.countDown();
        }
    }
}

class UnplaceUser extends BaseUser{
    private ContainerId containerId;
    UnplaceUser(ResourceManager manager, CountDownLatch countDownLatch, ContainerId containerId){
        super(manager, countDownLatch);
        this.containerId = containerId;
    }

    @Override
    public void run() {
        try{
            manager.unplaceContainer(containerId);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            countDownLatch.countDown();
        }
    }
}
