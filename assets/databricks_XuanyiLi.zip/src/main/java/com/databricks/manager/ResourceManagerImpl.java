package com.databricks.manager;

import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * The resource manager should place and unplace containers onto instances. The resource manager
 * should take in a cloud provider, a fixed instance size, and a fixed container size.
 */
public class ResourceManagerImpl implements ResourceManager {

    // ADD YOUR CODE HERE.

    // used for parallel allocation of cloud instances
    private ExecutorService executor;
    private CloudProvider provider;
    private double instanceSizeGB;
    private double containerSizeGB;

    // dictionary, containerId : cloudInstance
    public final Map<ContainerId, Instance> containerCloudMap = new ConcurrentHashMap<>();
    // set of cloud instances that can fit at least one container.
    private final Set<Instance> idleInstances = new HashSet<>();

    /**
     * Constructor for the resource manager.
     *
     * @param provider the cloud provider that we request instances from.
     * @param instanceSizeGB the size of all instances that is provided by the cloud provider.
     * @param containerSizeGB the size of all containers we want to place on instances.
     */
    public ResourceManagerImpl(CloudProvider provider, double instanceSizeGB, double containerSizeGB) {
        // ADD YOUR CODE HERE.
        executor = Executors.newCachedThreadPool();
        this.provider = provider;
        this.instanceSizeGB = instanceSizeGB;
        this.containerSizeGB = containerSizeGB;
        idleInstances.addAll(provider.getAllInstances());
    }

    /**
     * Places numContainers containers onto instances. If there are not enough resources with the
     * instances we currently have, request from the cloud provider for more instances. This method
     * should only return once all containers have been successfully placed. This method is
     * thread-safe.
     *
     * @param numContainers number of containers to place.
     * @return a list of containerIds which are IDs that are globally unique across all instances.
     */
    public List<ContainerId> placeContainers(int numContainers) {
        // ADD YOUR CODE HERE.
        // list of new containers' id
        List<ContainerId> ans = new ArrayList<>();

        // instead of synchronized (this)
        synchronized (idleInstances){
            int restNum = placeContainerHelper(numContainers, ans);
            // numContainers containers must be allocated on new cloud instances
            if(restNum>0){
                int numContainerSingleInstance = (int) Math.floor(instanceSizeGB/containerSizeGB);
                int numNewInstance = (int) Math.ceil( 1.0*restNum / numContainerSingleInstance);
                idleInstances.addAll(allocateInstances(numNewInstance));
                placeContainerHelper(restNum, ans);
            }
        }

        return ans;
    }

    /**
     * Get the ID of the instance where the input container is placed on.
     * This method is thread-safe.
     *
     * @param containerId the container id.
     * @return id of the instance where container resides.
     * @throws IllegalArgumentException if this container does not exist (i.e., is not placed on an
     *                                  instance).
     */
    public InstanceId getInstanceId(ContainerId containerId) {
        // ADD YOUR CODE HERE.
        // concurrent hashmap would not lock read operation except a few corner case
        // thus improve the throughput
        Instance instance = containerCloudMap.get(containerId);
        if(instance == null){
            throw new IllegalArgumentException(containerId.toString() + " does not exist.");
        }
        return instance.getInstanceId();
    }

    /**
     * Unplace a container from its host instance. This method is thread-safe.
     *
     * @param containerId the container id.
     * @return id of the instance where container resided.
     * @throws IllegalArgumentException if this container does not exist (i.e., is not placed on an
     *                                  instance).
     */
    public InstanceId unplaceContainer(ContainerId containerId) {
        // ADD YOUR CODE HERE.

        Instance instance = containerCloudMap.remove(containerId);
        if(instance == null){
            throw new IllegalArgumentException(containerId.toString() + " does not exist.");
        }
        instance.unplaceContainer(containerId);

        // cloud instance could fit at least one new container
        // thus add it to the set of idle instances
        // set ensure the Uniqueness
        synchronized (idleInstances){
            idleInstances.add(instance);
        }
        return instance.getInstanceId();
    }

    /**
     * helper method
     * Places #numContainers containers onto current idle instances.
     * Note, this helper method can only be called by placeContainers() to make it thread-safe.
     *
     * @param numContainers number of containers to place.
     * @param allocatedContainers store ids of new allocated containers
     * @return num of containers that cannot be fitted onto current instances. If result is
     *                                  larger thant zero, it indicates the caller to request more instances.
     */
    private int placeContainerHelper(int numContainers, List<ContainerId> allocatedContainers){
        Iterator<Instance> iter = idleInstances.iterator();
        int restNum = numContainers;
        while(iter.hasNext() && restNum>0){
            Instance curInstance = iter.next();
            double freeSpace = curInstance.getRemainingMemoryGB();
            // fit containers into currence instances as many as possible
            int singleFitNum = Math.min(restNum, (int) Math.floor(freeSpace/containerSizeGB));
            for(int i=0; i<singleFitNum; i++){
                ContainerId containerId = curInstance.placeContainer(containerSizeGB);
                allocatedContainers.add(containerId);
                containerCloudMap.put(containerId, curInstance);
            }
            restNum -= singleFitNum;
            // currence could instances cannot fit containers anymore
            if(curInstance.getRemainingMemoryGB()<containerSizeGB){
                iter.remove();
            }
        }
        return restNum;
    }

    /**
     * helper method
     * request #numInstance cloud instances from cloud provider
     * parallel request for each instance by commit the runner job to threadpool
     * Note, this method can only be called by placeContainers() to make it thread-safe.
     *
     * @param numInstance number of containers to request.
     * @return list of new cloud instances required from cloud provider
     */
    private List<Instance> allocateInstances(int numInstance){
        List<CompletableFuture<Instance>> futureInstances = new ArrayList<>();
        for(int i=0; i<numInstance; i++){
            futureInstances.add(CompletableFuture.supplyAsync(()->provider.requestInstance(), executor));
        }
        return futureInstances.stream().map(CompletableFuture::join).collect(Collectors.toList());
    }

    /**
     * shutdown threadpool during Garbage Collection
     *
     */
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        executor.shutdown();
    }
}
